USE [InventarioAviones]
GO

/****** Object:  StoredProcedure [dbo].[sp_Aterrizaje]    Script Date: 11/12/2023 21:11:11 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[sp_Aterrizaje]
	-- Add the parameters for the stored procedure here
	
	@Mision varchar(30),
	@Despegue varchar(13),
	@FechaDespegue date,
	@HoraDespegue time,
	@Serie varchar(30),
	@Marca varchar(30),
	@Modelo varchar(30),
	@FechaAterrizaje datetime,
	@PerdidaNave bit,
	@PerdidaHumana varchar(30),
	@Rescate bit
	
AS
BEGIN
	
	SET NOCOUNT ON;
	
    -- Insert statements for procedure here
	 INSERT INTO ATERRIZAJE(Mision, Despegue, FechaDespegue, HoraDespegue, Serie, Marca, Modelo, FechaAterrizaje, PerdidaNave, PerdidaHumana, Rescate)
	 VALUES(@Mision, @Despegue, @FechaDespegue, @HoraDespegue, @Serie, @Marca, @Modelo, @FechaAterrizaje, @PerdidaNave, @PerdidaHumana, @Rescate )


END
GO

