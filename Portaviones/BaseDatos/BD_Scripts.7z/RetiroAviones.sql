USE [InventarioAviones]
GO

/****** Object:  Table [dbo].[RetiroAviones]    Script Date: 11/12/2023 21:09:01 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[RetiroAviones](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Serie] [varchar](30) NOT NULL,
	[Marca] [varchar](30) NOT NULL,
	[Modelo] [varchar](30) NOT NULL,
	[NombreFantasia] [varchar](30) NOT NULL,
	[Detalle] [varchar](50) NOT NULL,
	[Tecnico] [varchar](50) NOT NULL,
 CONSTRAINT [PK_RegiroAviones] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[RetiroAviones]  WITH CHECK ADD  CONSTRAINT [FK_RegiroAviones_IngresoAviones] FOREIGN KEY([Serie])
REFERENCES [dbo].[IngresoAviones] ([Serie])
GO

ALTER TABLE [dbo].[RetiroAviones] CHECK CONSTRAINT [FK_RegiroAviones_IngresoAviones]
GO


