USE [InventarioAviones]
GO

/****** Object:  Table [dbo].[IngresoAviones]    Script Date: 11/12/2023 21:08:54 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[IngresoAviones](
	[Serie] [varchar](30) NOT NULL,
	[Marca] [varchar](30) NOT NULL,
	[Modelo] [varchar](30) NOT NULL,
	[NombreFantasia] [varchar](30) NOT NULL,
	[DimensionAla] [float] NOT NULL,
	[Alto] [float] NOT NULL,
	[Largo] [float] NULL,
	[DistanciaVuelo] [float] NOT NULL,
	[Fecha] [datetime] NOT NULL,
	[Tecnico] [varchar](50) NOT NULL,
	[Activo] [bit] NOT NULL,
 CONSTRAINT [PK_Aviones] PRIMARY KEY CLUSTERED 
(
	[Serie] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

