USE [InventarioAviones]
GO

/****** Object:  Table [dbo].[DESPEGUES]    Script Date: 11/12/2023 21:08:38 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[DESPEGUES](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[DESPEGUE]  AS ((CONVERT([varchar](4),datepart(year,getdate()),(103))+'-DE-')+right('00000'+CONVERT([varchar],[ID]),(5))),
	[FECHA] [date] NOT NULL,
	[HORA] [time](7) NOT NULL,
	[SERIE] [varchar](30) NOT NULL,
	[MARCA] [varchar](30) NOT NULL,
	[MODELO] [varchar](30) NOT NULL,
	[TECNICO] [varchar](30) NOT NULL,
	[MISION] [varchar](30) NOT NULL,
	[PILOTO] [varchar](30) NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[DESPEGUES]  WITH CHECK ADD  CONSTRAINT [FK_DESPEGUES_IngresoAviones] FOREIGN KEY([SERIE])
REFERENCES [dbo].[IngresoAviones] ([Serie])
GO

ALTER TABLE [dbo].[DESPEGUES] CHECK CONSTRAINT [FK_DESPEGUES_IngresoAviones]
GO

