USE [InventarioAviones]
GO

/****** Object:  StoredProcedure [dbo].[InsertarAvion]    Script Date: 11/12/2023 21:10:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[InsertarAvion]
	-- Add the parameters for the stored procedure here
	@Serie varchar(30),
	@Marca varchar(30),
	@Modelo varchar(30),
	@NombreFantasia varchar(30),
	@DimensionAla float,
	@Alto float,
	@Largo float,
	@DistanciaVuelo float,
	
	@Tecnico varchar(50),
	@Activo bit
AS
BEGIN
	
	SET NOCOUNT ON;
	Declare @Fecha datetime

	SET @Fecha = GETDATE();
    -- Insert statements for procedure here
	 INSERT INTO IngresoAviones (Serie, Marca, Modelo, NombreFantasia, DimensionAla, Alto, Largo, DistanciaVuelo, Fecha, Tecnico, Activo)
	 VALUES(@Serie, @Marca, @Modelo, @NombreFantasia, @DimensionAla, @Alto, @Largo, @DistanciaVuelo, @Fecha, @Tecnico, @Activo)


END
GO

