USE [InventarioAviones]
GO

/****** Object:  StoredProcedure [dbo].[RetiroAvion]    Script Date: 11/12/2023 21:10:54 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[RetiroAvion]
	-- Add the parameters for the stored procedure here
	@Serie varchar(30),
	@Marca varchar(30),
	@Modelo varchar(30),
	@NombreFantasia varchar(30),
	@Detalle varchar(50),
	@Tecnico varchar(50)
	
AS
BEGIN
	
	SET NOCOUNT ON;
	
    -- Insert statements for procedure here
	 INSERT INTO RetiroAviones(Serie, Marca, Modelo, NombreFantasia, Detalle, Tecnico)
	 VALUES(@Serie, @Marca, @Modelo, @NombreFantasia, @Detalle, @Tecnico)
END
GO

