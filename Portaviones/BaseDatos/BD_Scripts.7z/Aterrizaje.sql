USE [InventarioAviones]
GO

/****** Object:  Table [dbo].[ATERRIZAJE]    Script Date: 11/12/2023 21:08:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ATERRIZAJE](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Mision] [varchar](30) NOT NULL,
	[Despegue] [varchar](13) NOT NULL,
	[FechaDespegue] [date] NOT NULL,
	[HoraDespegue] [time](7) NOT NULL,
	[Serie] [varchar](30) NOT NULL,
	[Marca] [varchar](30) NOT NULL,
	[Modelo] [varchar](30) NOT NULL,
	[FechaAterrizaje] [datetime] NOT NULL,
	[PerdidaNave] [bit] NOT NULL,
	[PerdidaHumana] [varchar](30) NOT NULL,
	[Rescate] [bit] NOT NULL
) ON [PRIMARY]
GO

