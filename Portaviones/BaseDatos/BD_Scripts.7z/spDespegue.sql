USE [InventarioAviones]
GO

/****** Object:  StoredProcedure [dbo].[Despegue]    Script Date: 11/12/2023 21:09:57 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[Despegue]
	-- Add the parameters for the stored procedure here
	
	@Fecha date,
	@Hora time,
	@Serie varchar(30),
	@Marca varchar(30),
	@Modelo varchar(30),
	@Tecnico varchar(30),
	@Mision varchar(30)
	
AS
BEGIN
	
	SET NOCOUNT ON;
	
    -- Insert statements for procedure here
	 INSERT INTO DESPEGUES (Fecha,Hora, Serie, Marca, Modelo, Tecnico, Mision)
	 VALUES(@Fecha, @Hora, @Serie, @Marca, @Modelo, @Tecnico, @Mision)


END
GO

