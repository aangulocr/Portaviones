USE [InventarioAviones]
GO

/****** Object:  StoredProcedure [dbo].[ListarAviones]    Script Date: 11/12/2023 21:10:34 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[ListarAviones]
	
	
AS
BEGIN
	
	SET NOCOUNT ON;
	
	SELECT Marca, Modelo, NombreFantasia, Fecha, Tecnico FROM IngresoAviones WHERE ACTIVO = 1 ORDER BY Modelo ASC ;
    
END
GO

